
import React from 'react';
import './index.css';

const SlotMachine = (Props) => {

    let {x, y, z} = Props;

    if ((x === y) && (y === z)) {

        return (
            <>
                <div className="slot_inner">
                    <h1>{x} {y} {z}</h1>
                    <h1>This is Matching</h1>
                    <hr className="Hr"/>
                </div>
            </>
        )
    }

    else {

        return (
            <>
                <div className="slot_inner">
                    <h1>{x} {y} {z}</h1>
                    <h1>This is Not Matching</h1>
                    <hr className="Hr"/>
                </div>
            </>
        )
    }
}

const App = () => {

    return (
        <>
            <h1 className="Heading">
                🎰 Welcome to  <span style={{ color: "red", backgroundColor: " #fff" }}>Slot Machine game</span> 🎰
        </h1>

        <div className="slotmachine">
            <SlotMachine x='😁' y='😃' z='😆' />
            <SlotMachine x='👽' y='👽' z='👽' />
            <SlotMachine x='🎅' y='🎄' z='🌨️' />
            <SlotMachine x='😇' y='😇' z='😇' />
        </div>


        </>
    );
}

export default App;