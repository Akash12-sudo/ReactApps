
import React from 'react';
import './index.css';

function Heading(){

    return (<h1 className="header">TOP 5 SCI-FI SERIES TO WATCH</h1>);
}

export default Heading;