import React from 'react';



const Sdata = [
    {
        id:1,
        sname: "DARK",
        imgsrc: "https://i.scdn.co/image/ab67706c0000bebb47b9df6681ecd9edec7fd8b7",
        title: "NETFLIX ORIGINAL SERIES",
        link: "https://www.netflix.com/in/title/80100172",
    },
    {
        id:2,
        imgsrc: "https://cdn.mos.cms.futurecdn.net/SnBZn39WWMmPNuf5F8wTtE.jpg",
        title: "AMAZON PRIME SERIES",
        sname: "THE EXPANSE",
        link: "https://www.primevideo.com/detail/The-Expanse/0MW6F85MD8486AE43GONNOR5F1",
    },
    {
        id:3,
        imgsrc: "https://www.the-sun.com/wp-content/uploads/sites/6/2020/03/NINTCHDBPICT000574320869.jpg",
        title: "NETFLIX ORIGINAL SERIES",
        sname: "THE 100",
        link: "https://www.netflix.com/in/title/70283264#:~:text=A%20century%20after%20Earth%20was,Creators%3AJason%20Rothenberg",
    },
    {
        id:4,
        imgsrc: "https://incitingsparks.files.wordpress.com/2018/11/ac2.png",
        title: "NETFLIX ORIGINAL SERIES",
        sname: "ALTERED CARBON",
        link: "https://www.netflix.com/in/title/80097140",
    },
    {
        id:5,
        imgsrc: "https://images-na.ssl-images-amazon.com/images/S/sgp-catalog-images/region_US/nbc-MRO-04-Full-Image_GalleryCover-en-US-1573192838675._UY500_UX667_RI_V2zTKjyoTcjnRRSieemk36TDFoTuAjkV_TTW_.jpg",
        title: "AMAZON PRIME SERIES",
        sname: "MR. ROBOT",
        link: "https://www.amazon.com/Mr-Robot-Season-1/dp/B00YBX664Q",
    },

];

export default Sdata;